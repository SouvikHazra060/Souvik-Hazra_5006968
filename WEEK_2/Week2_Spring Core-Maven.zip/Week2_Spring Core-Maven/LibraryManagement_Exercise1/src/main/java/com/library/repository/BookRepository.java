package com.library.repository;

public class BookRepository {

    public void performRepositoryAction() {
        System.out.println("Hello from Book Repository!");
    }
}
