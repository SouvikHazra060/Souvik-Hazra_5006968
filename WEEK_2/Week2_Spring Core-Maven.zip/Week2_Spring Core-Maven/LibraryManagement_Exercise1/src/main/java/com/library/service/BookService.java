package com.library.service;

public class BookService {

    public void performService() {
    	System.out.println("Hello from Book Service!");
      
    }
}
