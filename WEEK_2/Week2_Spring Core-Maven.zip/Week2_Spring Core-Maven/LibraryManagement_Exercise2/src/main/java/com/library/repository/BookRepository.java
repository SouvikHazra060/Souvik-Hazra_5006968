package com.library.repository;

public class BookRepository {

    public void performRepositoryAction() {
        System.out.println("2nd Hello from Book Repository!");
    }
}
