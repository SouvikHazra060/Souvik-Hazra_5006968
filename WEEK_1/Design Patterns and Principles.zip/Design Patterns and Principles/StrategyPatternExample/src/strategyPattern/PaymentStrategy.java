package strategyPattern;

public interface PaymentStrategy {
	void pay(double amount);
}
