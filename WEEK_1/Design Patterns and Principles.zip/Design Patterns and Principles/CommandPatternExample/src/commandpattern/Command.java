package commandpattern;

public interface Command {
	void execute();
}
