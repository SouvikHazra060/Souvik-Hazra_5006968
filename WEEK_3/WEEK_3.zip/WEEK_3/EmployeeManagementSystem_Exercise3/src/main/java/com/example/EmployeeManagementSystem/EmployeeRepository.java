package com.example.EmployeeManagementSystem;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Derived query methods
    List<Employee> findByDepartmentName(String departmentName);

    List<Employee> findByNameContaining(String name);
}
